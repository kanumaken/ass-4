# Load ggplot2
library(ggplot2)

# Set working directory if needed
# setwd("C:/Users/hp/Downloads")

# Load the cleaned dataset
df <- read.csv("C:/Users/hp/Downloads/netflix_cleaned.csv")

# Clean ratings
df$rating[df$rating == ""] <- "Not Rated"

# Count ratings
rating_counts <- table(df$rating)
top_ratings <- sort(rating_counts, decreasing = TRUE)[1:10]
top_ratings_df <- data.frame(Rating = names(top_ratings), Count = as.integer(top_ratings))

# Plot
ggplot(top_ratings_df, aes(x = reorder(Rating, Count), y = Count)) +
  geom_bar(stat = "identity", fill = "darkred") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Top 10 Ratings Distribution on Netflix", x = "Rating", y = "Number of Titles")
